# LSFG Android — A16 G99 enhanced build

Target:
- Samsung Galaxy A16 4G
- MediaTek Helio G99 / MT6789
- ARM Mali-G57 MC2
- 90 Hz display

## Default A16 profile
- 2x frame generation
- Flow Scale 0.50
- Performance mode ON
- Anti-artifacts OFF
- Low-latency pacing
- Queue depth 2
- VSync alignment ON
- 90 FPS output cap when the active display reports >= 89 Hz
- 60 FPS/auto behavior on lower-refresh displays

These are first-run defaults only. Existing preferences are not overwritten.

## Important implementation changes
1. Vulkan instance version is selected dynamically with vkEnumerateInstanceVersion.
2. The Android visible AHardwareBuffer path no longer requires Linux opaque-FD memory/semaphore extensions.
3. Mali AHB staging uses both source and destination strides, avoiding row drift when the allocator pads the destination.
4. Existing Mali robustness2 fallback, synchronization compatibility, FP16, AFBC/layout preservation, and CPU-blit stability patches remain intact.

## Build
The project requires:
- JDK 17
- Android SDK 35
- NDK 27.0.12077973
- Gradle 8.9 (the wrapper downloads it if it is not already cached)

From `lsfg-app/`:

    ./gradlew :app:assembleDebug

The arm64-v8a APK is produced under:

    app/build/outputs/apk/debug/

## Recommended first test on the A16
1. Install the arm64-v8a debug APK.
2. Keep MediaProjection as the first capture source.
3. Use 2x.
4. Leave Flow Scale at 0.50.
5. Keep anti-artifacts disabled initially.
6. Keep GPU/NPU/CPU post-processing disabled.
7. Use 90 Hz / 90 FPS output if the phone is actually running at 90 Hz.
8. Compare the frame graph and native log output before enabling extra features.

This build is experimental. It is optimized conservatively for the G99/Mali-G57; it does not assume that an untested root Vulkan hook or universal zero-copy path is safe on every Samsung firmware.
