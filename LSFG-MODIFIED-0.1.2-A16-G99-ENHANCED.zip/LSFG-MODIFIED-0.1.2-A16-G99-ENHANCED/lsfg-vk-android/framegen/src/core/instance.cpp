#include <volk.h>
#include <vulkan/vulkan_core.h>

#include "core/instance.hpp"
#include "common/exception.hpp"

#include <cstdint>
#include <memory>
#include <vector>
#ifdef __ANDROID__
#include <android/log.h>
#endif

using namespace LSFG::Core;

const std::vector<const char*> requiredExtensions = {

};

Instance::Instance() {
    volkInitialize();

    // Do not request Vulkan 1.3 unconditionally. Mali devices in the G57/G77
    // family are commonly exposed as Vulkan 1.1/1.2 even when the Android
    // loader itself is newer. Requesting 1.3 here makes vkCreateInstance fail
    // with VK_ERROR_INCOMPATIBLE_DRIVER before the device-side compatibility
    // code even gets a chance to run.
    uint32_t loaderApiVersion = VK_API_VERSION_1_0;
    if (vkEnumerateInstanceVersion != nullptr) {
        uint32_t reported = VK_API_VERSION_1_0;
        if (vkEnumerateInstanceVersion(&reported) == VK_SUCCESS) {
            loaderApiVersion = reported;
        }
    }
    const uint32_t requestedApiVersion =
        loaderApiVersion >= VK_API_VERSION_1_3 ? VK_API_VERSION_1_3 :
        loaderApiVersion >= VK_API_VERSION_1_2 ? VK_API_VERSION_1_2 :
        loaderApiVersion >= VK_API_VERSION_1_1 ? VK_API_VERSION_1_1 :
        VK_API_VERSION_1_0;

#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_INFO, "lsfg-vk-framegen",
        "Vulkan instance API selected: %u.%u (loader reports %u.%u)",
        VK_VERSION_MAJOR(requestedApiVersion), VK_VERSION_MINOR(requestedApiVersion),
        VK_VERSION_MAJOR(loaderApiVersion), VK_VERSION_MINOR(loaderApiVersion));
#endif

    if (requestedApiVersion < VK_API_VERSION_1_1) {
        throw LSFG::vulkan_error(
            VK_ERROR_INCOMPATIBLE_DRIVER,
            "Vulkan 1.1 is required by LSFG-Android");
    }

    // create Vulkan instance
    const VkApplicationInfo appInfo{
        .sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
        .pApplicationName = "lsfg-vk-base",
        .applicationVersion = VK_MAKE_VERSION(0, 1, 2),
        .pEngineName = "lsfg-vk-base",
        .engineVersion = VK_MAKE_VERSION(0, 1, 2),
        .apiVersion = requestedApiVersion
    };
    const VkInstanceCreateInfo createInfo{
        .sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
        .pApplicationInfo = &appInfo,
        .enabledExtensionCount = static_cast<uint32_t>(requiredExtensions.size()),
        .ppEnabledExtensionNames = requiredExtensions.data()
    };
    VkInstance instanceHandle{};
    auto res = vkCreateInstance(&createInfo, nullptr, &instanceHandle);
    if (res != VK_SUCCESS)
        throw LSFG::vulkan_error(res, "Failed to create Vulkan instance");

    volkLoadInstance(instanceHandle);

    // store in shared ptr
    this->instance = std::shared_ptr<VkInstance>(
        new VkInstance(instanceHandle),
        [](VkInstance* instance) {
            vkDestroyInstance(*instance, nullptr);
        }
    );
}
