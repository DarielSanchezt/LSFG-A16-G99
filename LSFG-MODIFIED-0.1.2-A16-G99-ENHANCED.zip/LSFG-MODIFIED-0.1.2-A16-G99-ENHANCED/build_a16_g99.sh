#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/lsfg-app"
chmod +x ./gradlew
./gradlew :app:assembleDebug
